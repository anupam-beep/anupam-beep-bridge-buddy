# BridgeAgent offline E1–E6 evidence cross-reference — candidate

**Status:** OFFLINE_TESTED_NOT_DEPLOYED. **No real Civil NX execution verified.**

`offline_evidence_cross_reference.verify_evidence_cross_reference()` is an additive,
read-only, fail-closed verifier. It combines the previously implemented bounded
file inventory with the signed capture/analysis receipt and independently pinned
checkpoint handoff checks. It does not modify the existing production agent.

## E1–E6 exact artifact contract

The schema-v1 `claims_raw` JSON has exactly one `relative_path` and SHA-256 claim
for each required gate, and a `capture_id` matching the signed receipt and handoff:

| Gate | Required bytes whose SHA-256 must match the claim |
| --- | --- |
| E1 | Original model snapshot bytes supplied to the verifier |
| E2 | Canonical JSON bytes of the analysis attestation followed by its 64 raw Ed25519 signature bytes |
| E3 | Original HTTP request bytes, held in memory; may contain credentials |
| E4 | Original HTTP response bytes |
| E5 | Canonical JSON bytes of the capture receipt followed by its 64 raw signature bytes |
| E6 | Canonical JSON bytes of the checkpoint anchor followed by its 64 raw signature bytes |

E7 is not verified by this gate. The E7 claim, if present, does **not** confer
engineering acceptance. Artifacts must reside within a bounded local evidence
root and pass `offline_evidence_inventory` checks. A matching hash is not proof
of trusted provenance or of transmission to Civil NX.

The pinned analysis, capture and anchor keys must be three distinct 32-byte
public keys. Independent trust policy must be supplied by a separate trusted
channel, never from the local evidence claims. The code cannot prove the
organizational independence of the external pin source.

The return status `OFFLINE_E1_E6_CHAIN_CONSISTENT_NOT_LIVE` means only that
supplied synthetic/offline inputs are internally consistent. The output always
marks `live_verified`, `result_extraction_verified`, `engineering_accepted`,
and `civil_nx_contacted` as `false`.

## Safe testing

Run only in an isolated offline test folder:

```sh
python -m unittest discover -p 'test_*.py' -q
python -m compileall -q .
```

Do not provide live credentials to synthetic tests. Do not copy production
private keys or live request captures into shareable archives. No actual
POST/TABLE API call is implemented here.

## Outstanding requirements

- Authentic, independently witnessed completed-analysis and original-byte evidence.
- Independent trust-store hosting, authenticated time, rollback protection and
  operational separation of keys and personnel.
- Windows file-security/race validation, credential redaction review and integration tests.
- Engineering verification of numerical output before any safety-critical acceptance.
