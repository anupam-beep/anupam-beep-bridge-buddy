# BridgeAgent — offline Civil NX evidence inventory (candidate)

**No network, MIDAS calls, analysis, model writes, saves, production deployment, or engineering acceptance.** This is a bounded inventory/triage tool, not a trusted capture witness or result extractor. It cannot establish that an analysis completed or that POST/TABLE returned valid numbers.

## What was checked against inherited artifacts

The previous `bridgeagent_post_table_offline_diagnostic_cycle.zip` contains 68 entries (14 test modules, 13 candidate Python modules, 9 cycle reports, 5 SHA manifests, 1 explicitly synthetic fixture, 26 other items). All **67** inherited files covered by `sha256_manifest_post_table.json` matched the manifest. Those matches only establish continuity with the inherited manifest, **not** independent trust or model authenticity. The prior ZIP central directory and historical reports do not authenticate E1–E7. A prior report describes HTTP 200 `{"message":""}`, which is **not** a numerical result table. No genuine completed-analysis witness or numerical result capture was discovered in the inspected package.

## E1–E7 gates

| Gate | Evidence | Current status based on inspected package |
| --- | --- | --- |
| E1 | Independently established active model identity | NOT ESTABLISHED |
| E2 | Authenticated completed analysis | NOT ESTABLISHED |
| E3 | Original request bytes and exact POST/TABLE selectors | NOT ESTABLISHED |
| E4 | Original response bytes with numeric HEAD/DATA | NOT ESTABLISHED |
| E5 | Independently signed capture receipt | NOT ESTABLISHED |
| E6 | Independently anchored checkpoint | NOT ESTABLISHED |
| E7 | Independent numerical/engineering verification | NOT EVALUATED |

## Two offline modes

1. Inspect the **ZIP central-directory metadata only** (no extraction):

   `python -m offline_evidence_inventory --prior-archive path/to/prior_package.zip`

2. Verify an operator-prepared, **sanitized, untrusted** claims manifest against a local directory:

   `python -m offline_evidence_inventory --root path/to/evidence --claims path/to/claims.json`

   Manifest schema: `{"schema_version":1,"capture_id":"offline-example","artifacts":[{"gate":"E1","relative_path":"evidence/model_identity.bin","sha256":"<64 lowercase hex>"}]}`.

   `PRESENT_HASH_MATCH_UNAUTHENTICATED` means only that the local file hashes to the supplied digest. The manifest is self-asserted and **does not validate signatures, independent trust anchors, timestamps, capture transmission, analysis completion, or engineering correctness**. All seven gates remain unauthenticated even if all hashes match. No automatic promotion or certification is possible.

Output is bounded to gate names, reason codes and counts. It does not print artifact names, raw bytes, capture IDs, API keys, or request/response bodies. Input rejects traversal, symlinks, hardlinks, nonregular files, duplicate keys, duplicate paths, malformed hashes, oversize files and suspicious ZIP metadata. Sensitive bytes are only hashed locally; the user must keep originals protected.

## Remaining limitations and security review

* Filesystem time-of-check/time-of-use attacks remain possible with a hostile concurrent writer, especially replacement of parent directories; do not use against adversarial writable folders or as a production trust boundary.
* ZIP metadata classification is heuristic and does not validate archive member contents, provenance, signature or authenticity. Manifest SHA continuity is not independent authentication.
* Hashes do not prove bytes were sent to/received from MIDAS; no independent witness or remote anchor has been deployed.
* No verified original-byte captures, approved external manual ingestion, real result rows, or independently verified engineering outputs were available in this cycle.

**Next priority:** Create an offline cross-reference between signed capture receipt identifiers and independently anchored E1–E6 evidence, then exercise it with genuine authorized read-only evidence once separately approved. Do not execute Civil NX queries without explicit permission.

Run offline tests: `python -m unittest discover -q`.
