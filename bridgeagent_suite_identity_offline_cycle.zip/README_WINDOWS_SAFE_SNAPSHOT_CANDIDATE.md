# BridgeAgent: race-resistant offline evidence snapshot (candidate)

**Status: OFFLINE_TESTED_NOT_DEPLOYED.** This is not a live MIDAS Civil NX integration and not engineering certification. The existing production BridgeAgent is unchanged.

`offline_snapshot_reader.snapshot_sha256(root, relative)` is a read-only, bounded SHA-256 snapshot reader. It returns only digest, size, and a neutral status. It never exports file contents or filenames. `offline_evidence_inventory_hardened.inventory_hardened()` is an opt-in candidate E1–E7 inventory integration; the original inventory remains unchanged.

## Defensive controls

- Rejects traversal, absolute/drive paths, alternate data streams, Windows device names, invalid characters, trailing dots/spaces, excessive depth and oversized files.
- POSIX: traverses relative directories through opened directory file descriptors with `O_DIRECTORY | O_NOFOLLOW`; reads an opened, regular, single-link file; verifies device/inode, size, mtime and ctime after reading. Inode pinning prevents path swaps from redirecting an already opened file.
- Windows **implementation only, not Windows-tested**: uses Win32 `CreateFileW` to open every drive/root/child component while holding parent handles, rejects reparse points, uses read-only access and `FILE_SHARE_READ` (no share-write/delete), checks file identity and modification time before/after reading. It fails closed if secure opening is unavailable.
- No MIDAS API, credentials, network, file modifications, save operations, model analyses, or production changes.

## Verification performed

- 431/431 offline tests pass on Linux (405 inherited, 26 new), including simulated path substitution and in-flight modification.
- Python `compileall` passed.
- Inherited SHA-256 manifest: 84/84 self-declared digests matched (integrity only; not independent authenticity).
- Windows implementation **requires an actual Windows 10/11 test run and security review** before deployment. This Linux run does not establish Windows filesystem behavior.

## Remaining limitations

- POSIX assumes a trusted root directory path; symlinks in *ancestors of the root* are not independently resolved. Never accept an attacker-selected root.
- POSIX concurrent in-place writes can occur; metadata comparison detects common mutations but cannot guarantee a perfectly atomic snapshot under a hostile writer. Use offline/quiescent evidence or an independently immutable store.
- Windows access control, file-sharing behavior, network filesystems, junctions, and long paths are unvalidated; denial of sharing may cause conservative read failures.
- A file hash does not prove who created the file, that a request was sent, or that a Civil NX analysis completed. E7 engineering acceptance remains prohibited.

## Safe commands

From the unpacked candidate folder, using synthetic test files only:

```sh
python -m unittest discover -p 'test_*.py' -q
python -m compileall -q .
```

No actual Civil NX capture or live credentials should be placed in a shareable ZIP. The next priority is to run this exact suite on a Windows test machine with only synthetic fixtures, then review the fail-closed results before considering a secure read-only capture intake.
