# BridgeAgent candidate — Windows-native synthetic snapshot Dojo gate

**Scope:** offline candidate files only. No MIDAS Civil NX requests, model analysis, model write/save, broker, network, production update, or engineering acceptance. All test input is generated in temporary directories and removed by unittest cleanup. Do not point this package at any live model or real evidence. This gate is **not a security certification**.

## What changed

The earlier Windows fault-injection simulator could run on Linux but could not establish actual Windows filesystem sharing or rename behavior. This candidate adds two **native-only** tests: attempt to open a writer while the snapshot's Win32 handle is held, and attempt to rename the file while that handle is held. Both operations must be rejected by Windows, and the final SHA-256 must remain correct. These two tests are skipped on Linux, not counted as passes.

The new `offline_windows_dojo_gate.py` runs a fixed allowlist of five offline suites only on a native Windows Python runtime. It checks a self-declared source lock, exact discovered test counts, zero failures/errors, zero skips in the native runtime suite, and only an explicit list of expected POSIX-only skips in other suites. A pass is labeled `WINDOWS_SYNTHETIC_TESTS_PASS`, never engineering acceptance. A missing Windows runtime, altered file, skipped native test, missing suite, failed test or unexpected skip yields `BLOCKED`.

## Native Windows test procedure (later, on an isolated Windows test host)

1. Extract the ZIP into a **separate test folder** on a local fixed drive. Do not extract it into a live BridgeAgent installation, Civil NX project, or production repository.
2. In PowerShell, from that extracted test folder, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\run_windows_synthetic_dojo.ps1`. The script only launches local Python unit tests; it does not need a MIDAS API key or network access.
3. Retain the emitted JSON summary. A `BLOCKED` result is not a successful test. Even a pass is **self-reported synthetic runtime evidence**, not independent Windows security certification or proof of real Civil NX result extraction.

## Known limitations and fail-closed boundaries

- **NOT RUN ON WINDOWS:** this package was created and regression-tested on Linux. The two new native-only tests were discovered but skipped on Linux.
- Windows symlink tests may require appropriate privileges. Any skip in the native runtime suite blocks the Windows gate rather than being silently accepted.
- The SHA-256 lock protects against accidental changes relative to the bundled lock. An attacker can replace both the lock and the files; the lock is not a signature or independent trust anchor.
- A pass does not prove all Windows reparse, ACL, share, race, antivirus or filesystem conditions are secure. Human review and independently trusted evidence remain mandatory for deployment.
- No authentic completed-analysis evidence or numerical `POST/TABLE` capture is present in the inherited candidate evidence chain. This package does not resolve the Civil NX result-extraction blocker.

## Matrix learning status

Candidate skill: `windows_native_synthetic_gate_and_sharing_dojo` — `OFFLINE_TESTED_NOT_DEPLOYED`. No new approved manuals were ingested. No engineering certification was issued. Promotion requires native Windows tests, independent security review, authenticated Civil NX result provenance, and explicit user approval.
