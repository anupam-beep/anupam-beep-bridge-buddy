# BridgeAgent candidate: Windows synthetic-suite identity binding

This offline candidate extends the earlier native-Windows test gate by pinning the exact identities of 102 tests across five suites. Discovery must match each suite's pinned digest, and the actual started-test identities must match discovery. Ten additional adversarial tests cover missing, duplicated, substituted, and forged identities.

Run offline on Linux/macOS for portable tests: `python -m unittest discover -p "test_*.py"`. This **does not** validate native Windows behavior. On an isolated Windows machine, run `powershell -NoProfile -ExecutionPolicy Bypass -File .\run_windows_synthetic_dojo.ps1` from the extracted candidate directory. This is synthetic testing only; it does not contact Civil NX. Do not run on an untrusted package.

A passing self-declared suite identity digest is not independent provenance, Windows security certification, or engineering acceptance. All Civil NX analysis/result-extraction and production promotion remain blocked.
