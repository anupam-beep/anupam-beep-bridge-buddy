"""Offline-only authenticated, restart-durable checkpoint-store *simulator*.

This module supplies a SQLite-backed local stand-in for a future independently
operated checkpoint authority. It has authenticated Ed25519 request/response
messages, transactional CAS, persistent prepare/commit/abort, idempotent request
IDs, and fail-closed response checks. No network transport, private key storage,
independent hosting, remote trust anchor, Civil NX call, or engineering approval.

IMPORTANT: same-host DB and signer are NOT an independent anti-rollback anchor.
Never treat this adapter as deployed production infrastructure.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import re
import sqlite3
import uuid
from pathlib import Path

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

from offline_result_certifier import canonical_bytes
from two_phase_checkpoint import CheckpointHold

REQ_DOMAIN = 'BridgeAgent:durable-pin-request:v1'
RESP_DOMAIN = 'BridgeAgent:durable-pin-response:v1'
CHECKPOINT_HEX = re.compile(r'^[0-9a-f]{64}$')
REQUEST_FIELDS = {'domain', 'store_id', 'client_id', 'request_id', 'operation', 'txid', 'old', 'new'}
RESPONSE_FIELDS = {'domain', 'store_id', 'request_id', 'request_sha256', 'revision', 'result'}
OPS = {'snapshot', 'status', 'prepare', 'commit', 'abort'}


def sha256(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def checkpoint_ok(value):
    return (isinstance(value, dict) and set(value) == {'count', 'head'}
            and type(value['count']) is int and value['count'] >= 0
            and isinstance(value['head'], str) and bool(CHECKPOINT_HEX.fullmatch(value['head'])))


def json_canonical(obj):
    return canonical_bytes(obj).decode('utf-8')


class DurablePinStoreServer:
    """In-process test stand-in for an independent checkpoint authority."""

    def __init__(self, db_path, *, store_id, client_id, pinned_client_public_key,
                 server_signing_key, initial_checkpoint):
        if not checkpoint_ok(initial_checkpoint):
            raise CheckpointHold('STORE_GENESIS_INVALID')
        if not isinstance(store_id, str) or not store_id or not isinstance(client_id, str) or not client_id:
            raise CheckpointHold('STORE_IDENTITY_INVALID')
        if not isinstance(pinned_client_public_key, bytes) or len(pinned_client_public_key) != 32:
            raise CheckpointHold('CLIENT_PUBLIC_KEY_INVALID')
        self.store_id, self.client_id = store_id, client_id
        self.client_pub = Ed25519PublicKey.from_public_bytes(pinned_client_public_key)
        self.signer = server_signing_key  # injected only; never written to DB
        self.db = sqlite3.connect(str(db_path), timeout=1.0, isolation_level=None)
        self.db.execute('PRAGMA busy_timeout=1000')
        self.db.execute('PRAGMA synchronous=FULL')
        self.db.execute('PRAGMA journal_mode=WAL')
        self.db.executescript('''
            CREATE TABLE IF NOT EXISTS identity (id INTEGER PRIMARY KEY CHECK(id=1), store_id TEXT NOT NULL, client_id TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS pin (id INTEGER PRIMARY KEY CHECK(id=1), count INTEGER NOT NULL, head TEXT NOT NULL, revision INTEGER NOT NULL);
            CREATE TABLE IF NOT EXISTS transactions (
                txid TEXT PRIMARY KEY, old_json TEXT NOT NULL, new_json TEXT NOT NULL,
                state TEXT NOT NULL CHECK(state IN ('PREPARED','COMMITTED','ABORTED'))
            );
            CREATE TABLE IF NOT EXISTS commands (
                request_id TEXT PRIMARY KEY, request_hash TEXT NOT NULL,
                response_json TEXT NOT NULL, response_signature TEXT NOT NULL
            );
        ''')
        try:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute('SELECT store_id,client_id FROM identity WHERE id=1').fetchone()
            if row is None:
                self.db.execute('INSERT INTO identity VALUES(1,?,?)', (store_id, client_id))
                self.db.execute('INSERT INTO pin VALUES(1,?,?,0)', (initial_checkpoint['count'], initial_checkpoint['head']))
            elif row != (store_id, client_id):
                raise CheckpointHold('STORE_IDENTITY_CHANGED')
            # Existing state is NEVER silently reset to the requested genesis.
            self.db.execute('COMMIT')
        except Exception:
            if self.db.in_transaction: self.db.execute('ROLLBACK')
            self.db.close()
            raise

    def close(self):
        self.db.close()

    def _current(self):
        count, head, revision = self.db.execute('SELECT count,head,revision FROM pin WHERE id=1').fetchone()
        cp = {'count':count,'head':head}
        if not checkpoint_ok(cp) or type(revision) is not int or revision < 0:
            raise CheckpointHold('STORE_PIN_CORRUPT')
        return cp, revision

    def _tx(self, txid):
        row = self.db.execute('SELECT old_json,new_json,state FROM transactions WHERE txid=?', (txid,)).fetchone()
        if row is None: return None
        old, new, state = json.loads(row[0]), json.loads(row[1]), row[2]
        if not checkpoint_ok(old) or not checkpoint_ok(new) or state not in {'PREPARED','COMMITTED','ABORTED'}:
            raise CheckpointHold('STORE_TRANSACTION_CORRUPT')
        return {'txid':txid,'old':old,'new':new,'state':state}

    def _operate(self, req):
        op, txid, old, new = req['operation'], req['txid'], req['old'], req['new']
        cp, rev = self._current()
        if op == 'snapshot':
            return {'checkpoint':cp}, rev
        if op == 'status':
            tx = self._tx(txid)
            if tx and tx['state'] == 'COMMITTED':
                return {'state':'COMMITTED','document':tx['new']}, rev
            if tx and tx['state'] == 'PREPARED':
                return {'state':'PREPARED','document':{'txid':txid,'old':tx['old'],'new':tx['new']}}, rev
            return {'state':'UNKNOWN','document':None}, rev
        tx = self._tx(txid)
        if op == 'prepare':
            if tx:
                if tx['old'] != old or tx['new'] != new or tx['state'] == 'ABORTED':
                    raise CheckpointHold('STORE_TXID_CONFLICT')
                return {'ack':'PREPARED' if tx['state']=='PREPARED' else 'ALREADY_COMMITTED'}, rev
            if self.db.execute("SELECT 1 FROM transactions WHERE state='PREPARED' LIMIT 1").fetchone():
                raise CheckpointHold('STORE_PENDING_CONFLICT')
            if cp != old: raise CheckpointHold('STORE_CAS_FAILED')
            if new['count'] != old['count']+1 or new['head'] == old['head']:
                raise CheckpointHold('STORE_NON_MONOTONIC_CHECKPOINT')
            self.db.execute('INSERT INTO transactions VALUES(?,?,?,?)',
                            (txid,json_canonical(old),json_canonical(new),'PREPARED'))
            self.db.execute('UPDATE pin SET revision=revision+1 WHERE id=1')
            return {'ack':'PREPARED'}, rev+1
        if op == 'commit':
            if not tx or tx['old'] != old or tx['new'] != new:
                raise CheckpointHold('STORE_PREPARE_MISSING_OR_CONFLICT')
            if tx['state'] == 'COMMITTED':
                if cp != new: raise CheckpointHold('STORE_COMMITTED_PIN_MISMATCH')
                return {'ack':'ALREADY_COMMITTED'}, rev
            if tx['state'] != 'PREPARED': raise CheckpointHold('STORE_TRANSACTION_ABORTED')
            if cp != old: raise CheckpointHold('STORE_CAS_FAILED')
            self.db.execute('UPDATE pin SET count=?,head=?,revision=revision+1 WHERE id=1',
                            (new['count'],new['head']))
            self.db.execute("UPDATE transactions SET state='COMMITTED' WHERE txid=?",(txid,))
            return {'ack':'COMMITTED'}, rev+1
        if op == 'abort':
            if tx and (tx['old'] != old or tx['new'] != new or tx['state']=='COMMITTED'):
                raise CheckpointHold('STORE_ABORT_CONFLICT')
            if tx and tx['state']=='PREPARED':
                if cp != old: raise CheckpointHold('STORE_CAS_FAILED')
                self.db.execute("UPDATE transactions SET state='ABORTED' WHERE txid=?",(txid,))
                self.db.execute('UPDATE pin SET revision=revision+1 WHERE id=1')
                return {'ack':'ABORTED'}, rev+1
            return {'ack':'NOT_PREPARED'}, rev
        raise CheckpointHold('STORE_OPERATION_INVALID')

    def dispatch(self, request, signature_hex):
        if not isinstance(request,dict) or set(request)!=REQUEST_FIELDS:
            raise CheckpointHold('STORE_REQUEST_SCHEMA_INVALID')
        if request['domain']!=REQ_DOMAIN or request['store_id']!=self.store_id or request['client_id']!=self.client_id:
            raise CheckpointHold('STORE_REQUEST_IDENTITY_INVALID')
        if request['operation'] not in OPS or not isinstance(request['request_id'],str) or not request['request_id']:
            raise CheckpointHold('STORE_REQUEST_OPERATION_INVALID')
        op, txid, old, new = request['operation'], request['txid'], request['old'], request['new']
        if op in {'snapshot','status'}:
            if old is not None or new is not None: raise CheckpointHold('STORE_REQUEST_EXTRANEOUS_CHECKPOINT')
            if (op=='snapshot' and txid is not None) or (op=='status' and (not isinstance(txid,str) or not txid)):
                raise CheckpointHold('STORE_REQUEST_TXID_INVALID')
        elif not isinstance(txid,str) or not txid or not checkpoint_ok(old) or not checkpoint_ok(new):
            raise CheckpointHold('STORE_REQUEST_CHECKPOINT_INVALID')
        try:
            signature = bytes.fromhex(signature_hex)
            if len(signature)!=64: raise ValueError('bad length')
            self.client_pub.verify(signature,canonical_bytes(request))
        except (ValueError,TypeError,InvalidSignature):
            raise CheckpointHold('STORE_CLIENT_AUTHENTICATION_FAILED') from None
        request_hash=sha256(canonical_bytes(request))
        try:
            self.db.execute('BEGIN IMMEDIATE')
            previous=self.db.execute('SELECT request_hash,response_json,response_signature FROM commands WHERE request_id=?',
                                     (request['request_id'],)).fetchone()
            if previous:
                if not hmac.compare_digest(previous[0],request_hash):
                    raise CheckpointHold('STORE_REQUEST_ID_REUSE_CONFLICT')
                response, response_sig = json.loads(previous[1]),previous[2]
            else:
                result, revision=self._operate(request)
                response={'domain':RESP_DOMAIN,'store_id':self.store_id,
                          'request_id':request['request_id'],'request_sha256':request_hash,
                          'revision':revision,'result':result}
                response_sig=self.signer.sign(canonical_bytes(response)).hex()
                self.db.execute('INSERT INTO commands VALUES(?,?,?,?)',
                                (request['request_id'],request_hash,json_canonical(response),response_sig))
            self.db.execute('COMMIT')
            return response,response_sig
        except Exception:
            if self.db.in_transaction: self.db.execute('ROLLBACK')
            raise


class AuthenticatedDurablePinClient:
    """Adapter matching TwoPhaseCheckpoint pin-store interface; transport is in-process ONLY."""
    def __init__(self, server, *, store_id, client_id, client_signing_key, pinned_server_public_key,
                 independently_pinned_high_water=None):
        self.server=server
        self.store_id,self.client_id=store_id,client_id
        if not isinstance(pinned_server_public_key,bytes) or len(pinned_server_public_key)!=32:
            raise CheckpointHold('STORE_SERVER_KEY_INVALID')
        self.server_pub=Ed25519PublicKey.from_public_bytes(pinned_server_public_key)
        self.client_signer=client_signing_key
        if independently_pinned_high_water is not None and not checkpoint_ok(independently_pinned_high_water):
            raise CheckpointHold('STORE_INDEPENDENT_PIN_INVALID')
        # This optional pin must be obtained outside the local store; passing
        # its own snapshot back as a pin would NOT establish independence.
        self.independent_pin=(dict(independently_pinned_high_water)
                              if independently_pinned_high_water is not None else None)

    def _call(self, op, txid=None, old=None, new=None):
        req={'domain':REQ_DOMAIN,'store_id':self.store_id,'client_id':self.client_id,
             'request_id':str(uuid.uuid4()),'operation':op,'txid':txid,'old':old,'new':new}
        try:
            response,sig_hex=self.server.dispatch(req,self.client_signer.sign(canonical_bytes(req)).hex())
        except CheckpointHold: raise
        except Exception as exc: raise CheckpointHold('STORE_TRANSPORT_OR_STORAGE_FAILED') from exc
        if not isinstance(response,dict) or set(response)!=RESPONSE_FIELDS:
            raise CheckpointHold('STORE_RESPONSE_SCHEMA_INVALID')
        if (response['domain']!=RESP_DOMAIN or response['store_id']!=self.store_id
                or response['request_id']!=req['request_id']
                or not hmac.compare_digest(str(response['request_sha256']),sha256(canonical_bytes(req)))
                or type(response['revision']) is not int or response['revision']<0):
            raise CheckpointHold('STORE_RESPONSE_BINDING_INVALID')
        try:
            sig=bytes.fromhex(sig_hex)
            if len(sig)!=64: raise ValueError('bad signature')
            self.server_pub.verify(sig,canonical_bytes(response))
        except (ValueError,TypeError,InvalidSignature):
            raise CheckpointHold('STORE_SERVER_AUTHENTICATION_FAILED') from None
        return response['result']

    def snapshot(self):
        result=self._call('snapshot')
        cp=result.get('checkpoint') if isinstance(result,dict) else None
        if not checkpoint_ok(cp): raise CheckpointHold('STORE_SNAPSHOT_INVALID')
        pin=self.independent_pin
        if pin is not None and (cp['count'] < pin['count'] or
                (cp['count']==pin['count'] and cp['head']!=pin['head'])):
            raise CheckpointHold('STORE_INDEPENDENT_HIGH_WATER_ROLLBACK')
        # A count ABOVE the independent pin is not by itself proof of a
        # legitimate append; the two-phase coordinator must check provenance.
        return cp

    def status(self, txid):
        result=self._call('status',txid=txid)
        if not isinstance(result,dict) or set(result)!={'state','document'}:
            raise CheckpointHold('STORE_STATUS_INVALID')
        state,doc=result['state'],result['document']
        if state=='UNKNOWN' and doc is None: return state,doc
        if state=='COMMITTED' and checkpoint_ok(doc): return state,doc
        if (state=='PREPARED' and isinstance(doc,dict) and set(doc)=={'txid','old','new'}
                and doc['txid']==txid and checkpoint_ok(doc['old']) and checkpoint_ok(doc['new'])):
            return state,doc
        raise CheckpointHold('STORE_STATUS_INVALID')

    def prepare(self, txid, old, new):
        result=self._call('prepare',txid,old,new)
        if result not in ({'ack':'PREPARED'},{'ack':'ALREADY_COMMITTED'}):
            raise CheckpointHold('STORE_PREPARE_ACK_INVALID')

    def commit(self, txid, old, new):
        result=self._call('commit',txid,old,new)
        if result not in ({'ack':'COMMITTED'},{'ack':'ALREADY_COMMITTED'}):
            raise CheckpointHold('STORE_COMMIT_ACK_INVALID')

    def abort(self, txid, old, new):
        result=self._call('abort',txid,old,new)
        if result not in ({'ack':'ABORTED'},{'ack':'NOT_PREPARED'}):
            raise CheckpointHold('STORE_ABORT_ACK_INVALID')
