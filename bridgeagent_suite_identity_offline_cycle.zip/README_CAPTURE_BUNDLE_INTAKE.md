# BridgeAgent — sanitized capture-bundle intake gate (offline candidate)

This is an **offline** intake/format/secret-screening gate, not a Civil NX client,
not a trusted provenance verifier, and not an engineering acceptance gate.

## Input contract

Supply a `.zip` containing exactly these six top-level files:
`manifest.json`, `request.bin`, `response.json`, `analysis_attestation.json`,
`capture_receipt.json`, and `checkpoint_anchor.json`.

`manifest.json` must be an object with exactly `schema` (equal to
`bridgeagent.capture_bundle.v1`) and `artifacts`. The latter is an array of
five objects, one per role (`request`, `response`, `analysis_attestation`,
`capture_receipt`, `checkpoint_anchor`), each with exactly `role`, `path`,
`mime`, `bytes`, and lowercase-hex `sha256`. The role-to-filename and MIME
mapping is hard-coded. No other members or nested paths are permitted.

The checker uses bounded reads and conservative limits: 16 MiB compressed
archive, 4 MiB per member, 12 MiB total uncompressed, maximum 50:1
compression ratio, JSON maximum depth 32. It rejects duplicate/extra ZIP
entries, symlinks, unsupported compression, unsafe paths, malformed/duplicate-
key JSON, invalid MIME claims, hash/length mismatches, and common credential
markers including MIDAS MAPI keys, HTTP authorization, and private-key blocks.

It **rejects** suspected secrets; it does not redact, rewrite, persist, or
upload evidence. Rejections return reason codes only, never snippets.
Regex screening is defense in depth, **not a proof of complete sanitization**.
Never share raw API keys, tokens, or private keys. Preserve originals in a
separate secure vault under an approved retention policy; a sanitized copy
must **not** be represented as the exact signed/transmitted bytes.

## Verification boundary

A PASS is `OFFLINE_INTAKE_PASS_NOT_CERTIFIED`. It does **not** verify a
signature, external trust-store membership, actual network capture,
analysis completion, numerical correctness, or suitability for construction.
Pass this output only as a preliminary gate into the existing independent
handoff and provenance verifier; do not automatically promote it.

## Dojo / run

`python -m unittest discover -q`

`python offline_capture_bundle_intake.py path/to/sanitized_bundle.zip`

All tests use synthetic fixtures, temporary directories and temporary
SQLite databases. No live MIDAS connection, analysis, model write/save,
production modification, or engineering acceptance occurs.

## Civil NX result-extraction blocker

Prior observed response `HTTP 200` with `{"message":""}` remains incomplete;
there is no authenticated numerical POST/TABLE result in the available
artifacts. The documented successful table form includes named `HEAD` and
`DATA` arrays, but this gate cannot establish that the actual endpoint,
analysis run, result selector, or authentication was correct. Those are
unverified hypotheses, not established root causes. An authorized read-only
capture with protected credentials will eventually be needed for diagnosis.
