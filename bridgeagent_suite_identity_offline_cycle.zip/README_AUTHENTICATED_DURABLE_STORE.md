# BridgeAgent offline durable checkpoint-store candidate

**Status: OFFLINE_TESTED_NOT_DEPLOYED.** The SQLite service and client run in the same Python process. The server has an independently injected signing key *in the test fixture*, but is **not** an independently hosted, separately administered, remotely authenticated, anti-rollback checkpoint authority. It does not interact with Civil NX.

## Implemented

- `DurablePinStoreServer`: SQLite `WAL` / `synchronous=FULL` transactional state, durable `PREPARED` / `COMMITTED` / `ABORTED` records, CAS against old head/count, single prepared transaction, idempotent signed-command receipts, and monotonic checkpoint counts.
- `AuthenticatedDurablePinClient`: Ed25519-authenticated commands and server responses, strict request/response identity and SHA-256 binding, unique request IDs, fail-closed malformed status/ack handling, optional externally supplied high-water pin.
- The adapter exposes the existing `snapshot/status/prepare/commit/abort` contract, enabling an offline integration test with `TwoPhaseCheckpoint` and synthetic receipt evidence.
- Reopening the SQLite database does not silently reinitialize an existing checkpoint.

## Security and durability limits

- SQLite `synchronous=FULL` + WAL protects normal restart consistency under documented filesystem assumptions; it does **not** guarantee durability against all storage failures or malicious filesystem rewrites.
- An operator controlling both the database and signing key can forge a consistent stale snapshot. An **out-of-band pinned high-water checkpoint** is needed to detect rollback. The optional client-side pin is only trustworthy if acquired independently.
- In-process calls are not a network transport, mutual TLS, remote authentication, hardware key isolation, distributed locking, or external operational independence.
- Server signing and client signing private keys are injected at runtime and **not written** to the SQLite database or archive. Tests generate ephemeral keys.
- There is no live Civil NX analysis or result extraction, no production code modification, no engineering approval, and no promotion.

## Dojo and regression

Run `python -m unittest discover -v` from this directory. The test suite exercises authenticating both directions, invalid keys, altered/replayed messages, durable restarts, CAS conflicts, transaction recovery across a simulated crash, rollback detection against a separately supplied synthetic high-water pin, and all earlier offline gates.

## Next safe priority

Specify a remote checkpoint authority trust/transport protocol and a capture-evidence handoff, without enabling any Civil NX request. Until genuine completed-analysis and raw POST/TABLE evidence exist, the post-processing blocker remains unresolved.
