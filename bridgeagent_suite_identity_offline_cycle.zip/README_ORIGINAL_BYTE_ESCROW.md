# BridgeAgent — original-byte escrow candidate (offline, not deployed)

## Scope

This module stores **synthetic** original request/response byte arrays as AES-256-GCM authenticated ciphertext in a private local directory, and checks their SHA-256 hashes and capture/run identifiers against a **separately supplied** v1 handoff manifest. It never sends a request, reads a Civil NX model, starts analysis, writes/saves a Civil NX model, modifies the production BridgeAgent, or approves engineering results.

The module does not establish that supplied bytes were actually transmitted or received. It is not a live capture agent, independently trusted witness, or credential manager. No authentic Civil NX results are bundled.

## Interface and storage

- `escrow_capture(directory, key, capture_id, analysis_run_id, raw_request, raw_response)` accepts a 32-byte key held **outside** this module, and returns an opaque record ID and status only. No request, response, capture ID, analysis ID, key, or byte hashes are returned or written in plaintext to the escrow file. A fresh random 96-bit nonce is generated per record; AEAD associated data binds the record ID, version, and domain.
- `verify_escrow_binding(directory, key, record_id, trusted_handoff_manifest)` authenticates/decrypts internally and returns **reason codes only**. It checks the handoff v1 domain/version and compares request/response SHA-256, capture ID, and analysis-run ID. It never returns decrypted bytes. A positive result is `OFFLINE_ESCROW_BINDING_MATCH_NOT_LIVE` and cannot override a failure in the signed provenance or checkpoint gates.
- Storage is **POSIX prototype only**. It rejects directories that are not private (`0700`), symlinked final directories, non-private files (`0600`), invalid record IDs, and symlinked file reads. Private temporary ciphertext is fsynced and atomically published by a no-clobber hard link; an interrupted commit can leave a private pending ciphertext file, requiring controlled cleanup.
- The operator must control the **entire ancestor path**, supply and protect the encryption key from an independent secret manager, manage backups and retention, and prevent same-UID/root access. On Windows (the user's target platform), this filesystem adapter **fails closed** until Windows ACL, reparse-point, atomic-publish and backup semantics are independently implemented and reviewed.
- Input size is capped at 4 MiB each; stored JSON at 12 MiB. The plaintext is held transiently in Python memory and **cannot be guaranteed to be erased**. There is no key rotation, KMS integration, expiry or secure deletion. A compromised host or key defeats confidentiality. Cryptographic ciphertext authentication does not prove capture provenance.

## Cross-gate training and adversarial checks

Run from the extracted package:

```shell
python -m unittest discover -q
python -m compileall -q offline_original_byte_escrow.py test_offline_original_byte_escrow.py test_offline_escrow_handoff_integration.py
```

Dojo covers wrong keys, tampered ciphertext/nonce, record swaps, symlinks, unsafe file modes, oversize files, JSON duplicate keys, missing independent manifest, wrong run/capture/hash/domain, storage errors, secret non-disclosure, empty HTTP responses, sanitized/original hash mismatch, and interaction with the pre-existing signed-handoff gate. All test keys and HTTP messages are synthetic.

## Civil NX post-processing blocker — evidence review

The inherited offline artifacts contain a historical note of `HTTP 200` with `{"message":""}`. They do **not** contain independently authenticated proof that an analysis finished, an original HTTP capture with verified collector provenance, or an authentic numerical `POST/TABLE` response. This new escrow does not change that. Endpoint/selector mistakes, incomplete analysis, request schema errors, permissions and timing remain **hypotheses**, not verified root causes.

**Next investigation:** specify a strictly read-only diagnostic evidence matrix linking (1) model and run ID, (2) analysis-completion attestation, (3) exact permitted `POST/TABLE` request and response bytes, (4) server-side response shape and selector, (5) signed independent collector receipt and checkpoint. Do not execute Civil NX operations without explicit approval and safety review. A valid response shape and signed evidence are necessary but not sufficient for structural engineering acceptance.

## Certification boundary

`OFFLINE_TESTED_NOT_DEPLOYED`. No automatic promotion. No independent security review, Windows deployment validation, real witness, or genuine Civil NX result evidence. Human engineering approval remains a separate gate.
