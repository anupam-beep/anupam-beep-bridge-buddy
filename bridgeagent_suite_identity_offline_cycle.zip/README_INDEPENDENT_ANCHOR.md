# BridgeAgent: independently anchored checkpoint verifier (offline candidate)

**Status:** OFFLINE_TESTED_NOT_DEPLOYED. No MIDAS/Civil NX calls, analyses, model writes, saves, or engineering acceptance.

## What was implemented

`independent_checkpoint_anchor.verify_anchored_registry` accepts an existing
`OfflineReplayRegistry`, a signed checkpoint record, its detached Ed25519
signature, an independently supplied trust policy, and a trusted time.
The verifier checks domain separation, exact schema, pinned registry/signer
identity, Ed25519 signature, validity window (maximum 24 h), exact SHA-256
fingerprint of signed anchor, externally pinned head/count, and the complete
SQLite hash chain against that pinned checkpoint. Failures return `HOLD`.

## Trust-store policy and limitations

- The caller MUST obtain `pinned_public_key`, `latest_anchor_sha256`,
  `latest_checkpoint`, and identity bindings from a genuinely independent,
  authenticated store/channel. The literal `source` label is **not proof**.
- A signed old checkpoint plus an old database remains vulnerable to rollback
  if the trusted external high-water record is also rolled back or compromised.
- No anchor signing authority, network endpoint, key management, or actual
  independent trust store has been deployed or connected.
- The verifier intentionally accepts only the **latest externally pinned**
  checkpoint; a new registry append requires independently promoting the pin
  before a new verification can succeed.
- A crash between local append commit and independent pin promotion leaves a
  checkpoint gap requiring fail-closed reconciliation; do not silently reset
  the pin. This is the next engineering task.
- Time validity depends on a trusted external clock. Clock quality is not
  established by a Python datetime object.
- Cryptographic provenance never certifies numerical correctness, completed
  real-world analysis, or structural engineering adequacy.

## Offline test command

`python -m unittest discover -v`

All signing keys used by tests are ephemeral synthetic fixtures. The module
has no code to generate or persist a production signing key.
