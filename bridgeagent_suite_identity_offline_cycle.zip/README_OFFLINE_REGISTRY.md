# BridgeAgent offline replay registry — candidate, not deployed

This package contains a local-only prototype. It **does not** contact Civil NX, perform analysis, issue a signed witness receipt, modify a bridge model, or grant engineering acceptance.

## What was implemented

- `offline_replay_registry.py`: SQLite append-only receipt metadata ledger with serialized `BEGIN IMMEDIATE` writes, unique capture IDs, a deterministic SHA-256 hash chain, and an independently supplied checkpoint requirement.
- `accept_signed_receipt(...)` is an **intake** interface, not a signing/issuance service. It reuses the earlier analysis attestation, raw HTTP byte, response quality, and capture signature gates before appending metadata.
- `audit(pinned_checkpoint)` compares every chain entry and the final `(count, head)` to a checkpoint **pinned outside the registry**. An unanchored local hash chain cannot prove that the database has not been replaced or truncated.
- No raw requests/responses, API credentials, private keys, or structural numerical results are intentionally persisted. The database stores capture ID, collector ID, run ID, and hashes. These IDs are metadata and should still be access-controlled.

## Security limitations

1. A caller-provided checkpoint is **not** independent merely because it is passed as an argument. Deployment must pin it in a separately trusted storage/identity domain, with recovery, authentication and audit policies.
2. SQLite triggers and the chain are defense-in-depth, not protection against an administrator able to replace the database, alter the program, or compromise the independently pinned checkpoint.
3. The module does **not** create a real independent capture witness or a valid Civil NX analysis attestation. The tests use ephemeral synthetic Ed25519 keys.
4. A returned `OFFLINE_RECEIPT_REGISTERED` means synthetic/offline evidence checks passed, **not** that any live analysis or network exchange occurred.
5. No engineering result may be used until authentic, explicitly authorized analysis and capture provenance is independently established and engineering checks are performed.
6. This module is not installed into the user's BridgeAgent repository; review and approval are required for production integration.

## Local test

Run `python -m unittest discover -v` in this directory with `cryptography` installed. All fixtures are synthetic.
