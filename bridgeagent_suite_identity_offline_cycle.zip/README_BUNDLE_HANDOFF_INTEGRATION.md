# BridgeAgent: sanitized intake + read-only handoff integration (offline candidate)

## Scope and safety

This candidate links the existing sanitized ZIP intake gate to the existing signed-evidence handoff verifier. It is **not** a Civil NX client. It cannot start analysis, retrieve results, write/save a model, or approve engineering designs. No production repository was modified. All Dojo cases use synthetic records and ephemeral keys.

## Cross-gate contract

The intake bundle contains exactly six top-level members: `manifest.json`, `request.bin`, `response.json`, `analysis_attestation.json`, `capture_receipt.json`, and `checkpoint_anchor.json`. `manifest.json` remains the v1 five-role SHA-256/length manifest. The three signed JSON files now have a documented integration wrapper with **exactly** `record` (JSON object) and `signature_hex` (128 lowercase hexadecimal characters). The `record` is the exact object covered by the signature; the wrapper itself is not the signed record.

The caller separately supplies `trusted_handoff_manifest`, model evidence bytes, analysis public key, capture public key, pinned collector identity, trusted timestamp, registry, and an independently anchored checkpoint policy. **None** of these trust roots may be accepted from the ZIP. A signed checkpoint bundled by the submitter is not independent evidence without a separately pinned high-water checkpoint.

The adapter first validates archive structure, sizes, duplicate keys, digest/length integrity and common credential patterns; it then extracts validated members from the **same opened archive** in memory. It validates wrapper schemas and signatures, exact request/response hashes, model/run binding, numerical table shape, and anchored registry inclusion. An offline success is `OFFLINE_PIPELINE_CONSISTENT_NOT_LIVE`; `live_verified`, `engineering_accepted`, and `civil_nx_contacted` remain false.

### Important limitation

The secret scanner rejects common credentials. A sanitized `request.bin` **cannot be claimed to equal the exact transmitted HTTP request** if redaction changed its bytes. A synthetic byte match is not evidence of real transport. Authentic captures, if later approved, require a secure protected original-byte store, independent capture receipt, and out-of-band trust anchor. This integration does not solve the authentic-result-extraction blocker.

The candidate adjusts the credential keyword regex so legitimate `authorization_id` metadata is not mistaken for an HTTP `Authorization` header, while secret-bearing `Authorization`, `MAPI-Key`, `api_key`, etc. remain rejected. This was necessary for the existing signed attestation and receipt schemas to pass intake.

## Dojo

Run in this extracted directory:

```shell
python -m unittest discover -q
python -m compileall -q offline_capture_bundle_intake.py offline_bundle_handoff_pipeline.py
```

Cross-gate cases cover signed synthetic success; absent independent manifest; altered request/response with recalculated ZIP hashes; empty HTTP-200 result; forged analysis/capture/anchor signatures; wrong independent trust pins; incorrect model; malformed wrappers; duplicate JSON keys; secret screening; corrupted ZIP manifest; missing member; run mismatch; registry deletion/rollback; expired anchor; mismatched handoff checkpoint; wrong collector; and absence of raw evidence in result metadata.

## Promotion gate

Status **OFFLINE_TESTED_NOT_DEPLOYED**. Do not promote until a separate code review, independent trust-store assessment, an explicitly approved read-only capture plan, and genuine completed-analysis result evidence. Engineering acceptance is always a separate human decision.
